# Voting app

A Pen created on CodePen.io. Original URL: [https://codepen.io/Malaram-Official/pen/BaXoMKQ](https://codepen.io/Malaram-Official/pen/BaXoMKQ).

